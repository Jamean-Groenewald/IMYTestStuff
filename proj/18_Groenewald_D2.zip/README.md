#IMY 220 project u23524121 D1 readme

docker build -t u23524121 .

docker run --name u23524121 -p 3000:3000 u23524121